import React from 'react';
import Sidebar from '../components/Sidebar';
import TopHeader from '../components/TopHeader';
import KPICard from '../components/KPICard';
import SummaryCard from '../components/SummaryCard';
import MonthlyQuotationChart from '../components/MonthlyQuotationChart';
import QuoteStatusChart from '../components/QuoteStatusChart';
import ConversionFunnel from '../components/ConversionFunnel';
import PendingApprovalList from '../components/PendingApprovalList';
import RecentQuotationTable from '../components/RecentQuotationTable';
import TopSalesExecutives from '../components/TopSalesExecutives';

import { 
  FileText, 
  Banknote, 
  Calculator, 
  Target,
  FileEdit,
  Send,
  CheckCircle,
  Clock
} from 'lucide-react';

const QuotationDashboard = () => {
  return (
    <div className="flex min-h-screen bg-[#F8F9FC] font-sans">
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 ml-[260px] flex flex-col h-screen overflow-hidden">
        <TopHeader />
        
        {/* Scrollable Area */}
        <main className="flex-1 overflow-y-auto p-8">
          <div className="max-w-[1400px] mx-auto space-y-6">
            
            {/* ROW 1: KPI CARDS */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
              <KPICard 
                title="Total Quotations" 
                value="$12.4M" 
                trend="up" 
                trendValue={12.4} 
                icon={FileText} 
                iconBg="bg-red-50" 
                iconColor="text-red-600" 
              />
              <KPICard 
                title="Revenue Pipeline" 
                value="$8.2M" 
                trend="up" 
                trendValue={5.2} 
                icon={Banknote} 
                iconBg="bg-amber-50" 
                iconColor="text-amber-600" 
              />
              <KPICard 
                title="Avg. Quote Value" 
                value="$145k" 
                trend="down" 
                trendValue={2.1} 
                icon={Calculator} 
                iconBg="bg-purple-50" 
                iconColor="text-purple-600" 
              />
              <KPICard 
                title="Conversion Rate" 
                value="48%" 
                trend="up" 
                trendValue={8.0} 
                icon={Target} 
                iconBg="bg-emerald-50" 
                iconColor="text-emerald-600" 
              />
            </div>

            {/* ROW 2: SUMMARY CARDS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <SummaryCard icon={FileEdit} value="24" label="Drafts" iconBg="bg-gray-100" iconColor="text-gray-600" />
              <SummaryCard icon={Send} value="85" label="Sent" iconBg="bg-blue-50" iconColor="text-blue-600" />
              <SummaryCard icon={CheckCircle} value="42" label="Accepted" iconBg="bg-emerald-50" iconColor="text-emerald-600" />
              <SummaryCard icon={Clock} value="12" label="Expired" iconBg="bg-rose-50" iconColor="text-rose-600" />
            </div>

            {/* ROW 3: CHARTS (70 / 30) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[340px]">
              <div className="lg:col-span-8 h-full">
                <MonthlyQuotationChart />
              </div>
              <div className="lg:col-span-4 h-full">
                <QuoteStatusChart />
              </div>
            </div>

            {/* ROW 4: FUNNEL & APPROVALS (50 / 50) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[400px]">
              <div className="h-full">
                <ConversionFunnel />
              </div>
              <div className="h-full">
                <PendingApprovalList />
              </div>
            </div>

            {/* ROW 5: TABLE & EXECUTIVES (70 / 30) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[400px]">
              <div className="lg:col-span-8 h-full">
                <RecentQuotationTable />
              </div>
              <div className="lg:col-span-4 h-full">
                <TopSalesExecutives />
              </div>
            </div>

          </div>
        </main>
      </div>
    </div>
  );
};

export default QuotationDashboard;
