import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import BuilderTopHeader from '../components/BuilderTopHeader';
import ServiceAccordion from '../components/ServiceAccordion';
import QuotationTableEditor from '../components/QuotationTableEditor';
import QuoteSummaryCard from '../components/QuoteSummaryCard';
import ProfitMarginCard from '../components/ProfitMarginCard';
import EventInfoCard from '../components/EventInfoCard';
import ProposalGeneratorCard from '../components/ProposalGeneratorCard';
import { MapPin, Palette, Utensils, Music, Save } from 'lucide-react';

const initialData = {
  venue: [
    { id: 'v1', description: 'Grand Ballroom Rental (12 Hours)', qty: 1, price: 12500, discount: 0 }
  ],
  floral: [
    { id: 'f1', description: 'Premium Orchid Centerpieces', qty: 25, price: 180, discount: 5 },
    { id: 'f2', description: 'Entrance Floral Arch', qty: 1, price: 2200, discount: 0 }
  ],
  catering: [],
  entertainment: [
    { id: 'e1', description: 'Live String Quartet (3 Hours)', qty: 1, price: 3500, discount: 10 }
  ]
};

const QuotationBuilder = () => {
  const [sections, setSections] = useState(initialData);

  const calculateSubtotal = () => {
    let subtotal = 0;
    Object.values(sections).forEach(items => {
      items.forEach(item => {
        subtotal += (item.qty * item.price) * (1 - item.discount / 100);
      });
    });
    return subtotal;
  };

  const handleUpdate = (sectionKey, id, field, value) => {
    setSections(prev => ({
      ...prev,
      [sectionKey]: prev[sectionKey].map(item => 
        item.id === id ? { ...item, [field]: value } : item
      )
    }));
  };

  const handleDelete = (sectionKey, id) => {
    setSections(prev => ({
      ...prev,
      [sectionKey]: prev[sectionKey].filter(item => item.id !== id)
    }));
  };

  const handleAdd = (sectionKey) => {
    const newItem = {
      id: Math.random().toString(36).substring(7),
      description: 'New Item',
      qty: 1,
      price: 0,
      discount: 0
    };
    setSections(prev => ({
      ...prev,
      [sectionKey]: [...prev[sectionKey], newItem]
    }));
  };

  return (
    <div className="flex min-h-screen bg-[#F8F9FC] font-sans">
      <Sidebar />
      
      <div className="flex-1 ml-[260px] flex flex-col h-screen overflow-hidden">
        <BuilderTopHeader />
        
        <main className="flex-1 overflow-y-auto p-8 pb-20">
          <div className="max-w-[1400px] mx-auto">
            
            {/* Page Header */}
            <div className="mb-8">
              <div className="flex items-center gap-4 mb-2">
                <h1 className="text-[40px] font-bold text-gray-900 tracking-tight leading-none">
                  Royal Wedding Gala
                </h1>
                <div className="flex items-center gap-2 mt-1">
                  <span className="px-3 py-1 bg-[#F8E3A5] text-[#2F2100] text-[12px] font-bold rounded-full uppercase tracking-wider">
                    Premium Client
                  </span>
                  <span className="px-3 py-1 bg-[#EDE9FE] text-[#7C3AED] text-[12px] font-bold rounded-full uppercase tracking-wider">
                    Draft
                  </span>
                </div>
              </div>
              <p className="text-[16px] font-medium text-gray-500">
                Draft Quote #Q-8829 | Last edited 2 mins ago
              </p>
            </div>

            {/* Layout Grid */}
            <div className="flex flex-col xl:flex-row gap-8">
              
              {/* Left Column - Builder Content */}
              <div className="flex-1 xl:w-[70%]">
                
                {/* Section 1: Venue */}
                <ServiceAccordion icon={MapPin} title="Venue Selection">
                  <QuotationTableEditor 
                    items={sections.venue}
                    onAdd={() => handleAdd('venue')}
                    onUpdate={(id, f, v) => handleUpdate('venue', id, f, v)}
                    onDelete={(id) => handleDelete('venue', id)}
                  />
                </ServiceAccordion>

                {/* Section 2: Floral */}
                <ServiceAccordion icon={Palette} title="Floral & Decoration">
                  <QuotationTableEditor 
                    items={sections.floral}
                    onAdd={() => handleAdd('floral')}
                    onUpdate={(id, f, v) => handleUpdate('floral', id, f, v)}
                    onDelete={(id) => handleDelete('floral', id)}
                  />
                </ServiceAccordion>

                {/* Section 3: Catering (Empty State Example) */}
                <ServiceAccordion icon={Utensils} title="Gourmet Catering">
                  {sections.catering.length === 0 ? (
                    <div className="py-8 flex flex-col items-center justify-center text-center">
                      <p className="text-[15px] font-medium text-gray-500 mb-6">No catering items added yet.</p>
                      <div className="flex items-center gap-4">
                        <button 
                          onClick={() => handleAdd('catering')}
                          className="px-6 py-2.5 rounded-full border border-red-200 text-red-600 font-bold text-[14px] hover:bg-red-50 transition-colors"
                        >
                          Browse Catering Catalog
                        </button>
                        <button className="px-6 py-2.5 rounded-full bg-white border border-gray-200 text-gray-700 font-bold text-[14px] flex items-center gap-2 hover:bg-gray-50 shadow-sm">
                          <Save className="w-4 h-4" />
                          Save Draft
                        </button>
                      </div>
                    </div>
                  ) : (
                    <QuotationTableEditor 
                      items={sections.catering}
                      onAdd={() => handleAdd('catering')}
                      onUpdate={(id, f, v) => handleUpdate('catering', id, f, v)}
                      onDelete={(id) => handleDelete('catering', id)}
                    />
                  )}
                </ServiceAccordion>

                {/* Section 4: Entertainment */}
                <ServiceAccordion icon={Music} title="Entertainment & Sound">
                  <QuotationTableEditor 
                    items={sections.entertainment}
                    onAdd={() => handleAdd('entertainment')}
                    onUpdate={(id, f, v) => handleUpdate('entertainment', id, f, v)}
                    onDelete={(id) => handleDelete('entertainment', id)}
                  />
                </ServiceAccordion>

              </div>

              {/* Right Column - Sticky Panel */}
              <div className="w-full xl:w-[30%] relative">
                <div className="sticky top-0 pt-2">
                  <QuoteSummaryCard subtotal={calculateSubtotal()} />
                  <ProfitMarginCard />
                  <EventInfoCard />
                  <ProposalGeneratorCard />
                </div>
              </div>

            </div>

          </div>
        </main>
      </div>
    </div>
  );
};

export default QuotationBuilder;
