import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import ErrorBoundary from './ErrorBoundary';
import QuotationDashboard from './pages/QuotationDashboard';
import QuotationListPage from './pages/QuotationListPage';
import CreateQuotationStep1 from './pages/CreateQuotationStep1';
import QuotationBuilder from './pages/QuotationBuilder';
import ProposalStudio from './pages/ProposalStudio';
import GlobalPriceBook from './pages/GlobalPriceBook';
import Templates from './pages/Templates';
import Approvals from './pages/Approvals';
import ClientPortal from './pages/ClientPortal';

function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<QuotationDashboard />} />
          <Route path="/quotations" element={<QuotationListPage />} />
          <Route path="/quotations/new" element={<CreateQuotationStep1 />} />
          <Route path="/quotation-builder" element={<QuotationBuilder />} />
          <Route path="/proposals" element={<ProposalStudio />} />
          <Route path="/price-book" element={<GlobalPriceBook />} />
          
          {/* Added placeholders for requested missing pages */}
          <Route path="/templates" element={<Templates />} />
          <Route path="/approvals" element={<Approvals />} />
          <Route path="/client-portal" element={<ClientPortal />} />
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}

export default App;
